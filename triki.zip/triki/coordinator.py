"""Data update coordinator for a single Triki controller.

This is a *push* coordinator: it does not poll on a timer. Instead it keeps
a persistent BLE connection open and calls ``async_set_updated_data`` every
time a BLE notification arrives (throttled for the high-rate motion data,
immediate for the button state). This is the pattern Home Assistant's own
developer docs describe for push-based APIs.
"""
from __future__ import annotations

import asyncio
import logging
import struct
import time
from dataclasses import dataclass

from bleak import BleakClient
from bleak.backends.device import BLEDevice
from bleak.exc import BleakError
from bleak_retry_connector import BleakClientWithServiceCache, establish_connection

from homeassistant.components import bluetooth
from homeassistant.core import HomeAssistant, callback
from homeassistant.exceptions import HomeAssistantError
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator

from .const import (
    BATTERY_LEVEL_UUID,
    CMD_PREFIX,
    CMD_SLEEP,
    CMD_SUFFIX,
    CONNECT_TIMEOUT,
    FIRMWARE_REV_UUID,
    LED_CTRL_UUID,
    MIN_PUSH_INTERVAL,
    NOTIFY_HEADER,
    NOTIFY_LEN,
    RETRY_COOLDOWN,
    UART_RX_UUID,
    UART_TX_UUID,
)

_LOGGER = logging.getLogger(__name__)


@dataclass
class TrikiData:
    """Latest known state of one Triki controller."""

    available: bool = False
    battery: int | None = None
    firmware: str | None = None
    rssi: int | None = None
    accel_x: int = 0
    accel_y: int = 0
    accel_z: int = 0
    gyro_x: int = 0
    gyro_y: int = 0
    gyro_z: int = 0
    button_pressed: bool = False
    led_on: bool = False


class TrikiCoordinator(DataUpdateCoordinator[TrikiData]):
    """Owns the BLE connection to one Triki controller."""

    def __init__(self, hass: HomeAssistant, address: str, sample_rate: int) -> None:
        super().__init__(hass, _LOGGER, name=f"Triki {address}", update_interval=None)
        self.address = address
        self.sample_rate = sample_rate
        self.data = TrikiData()

        self._client: BleakClient | None = None
        self._last_push = 0.0
        self._connect_lock = asyncio.Lock()
        self._next_attempt = 0.0
        self._unregister_callbacks: list = []

    @property
    def device_name(self) -> str:
        """Short, human-friendly name derived from the BLE MAC."""
        return f"Triki {self.address.replace(':', '')[-6:]}"

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def async_start(self) -> None:
        """Start tracking the device and connect as soon as it is seen."""
        cancel = bluetooth.async_register_callback(
            self.hass,
            self._async_seen,
            bluetooth.BluetoothCallbackMatcher(address=self.address),
            bluetooth.BluetoothScanningMode.ACTIVE,
        )
        self._unregister_callbacks.append(cancel)

        ble_device = bluetooth.async_ble_device_from_address(
            self.hass, self.address, connectable=True
        )
        if ble_device is not None:
            _LOGGER.info("Triki %s: seen by Bluetooth, connecting", self.address)
            self._async_schedule_connect(ble_device)
        else:
            _LOGGER.info(
                "Triki %s: not seen by any adapter/proxy yet, waiting for advertisement "
                "(is it still connected to Zappka/phone?)",
                self.address,
            )

    async def async_stop(self) -> None:
        """Stop tracking and disconnect cleanly."""
        for cancel in self._unregister_callbacks:
            cancel()
        self._unregister_callbacks.clear()
        await self._async_disconnect()

    async def async_apply_sample_rate(self, sample_rate: int) -> None:
        """Apply a new sample rate (requires re-sending the start command)."""
        self.sample_rate = sample_rate
        if self._client is not None and self._client.is_connected:
            await self._async_send_start_stream(self._client)

    # ------------------------------------------------------------------
    # Connection handling
    # ------------------------------------------------------------------

    @callback
    def _async_seen(
        self,
        service_info: bluetooth.BluetoothServiceInfoBleak,
        change: bluetooth.BluetoothChange,
    ) -> None:
        if self.data.rssi is None:
            _LOGGER.info(
                "Triki %s: first advertisement received via %s",
                self.address,
                service_info.source,
            )
        self.data.rssi = service_info.rssi
        if self._client is None or not self._client.is_connected:
            self._async_schedule_connect(service_info.device)

    @callback
    def _async_schedule_connect(self, ble_device: BLEDevice) -> None:
        """Connect in the background (never block config entry setup)."""
        if self._connect_lock.locked() or time.monotonic() < self._next_attempt:
            return
        self.hass.async_create_background_task(
            self._async_connect(ble_device), f"triki_connect_{self.address}"
        )

    async def _async_connect(self, ble_device: BLEDevice) -> None:
        async with self._connect_lock:
            if self._client is not None and self._client.is_connected:
                return

            try:
                async with asyncio.timeout(CONNECT_TIMEOUT):
                    client = await establish_connection(
                        BleakClientWithServiceCache,
                        ble_device,
                        self.device_name,
                        disconnected_callback=self._on_disconnect,
                        max_attempts=2,
                    )
            except (BleakError, TimeoutError, EOFError) as err:
                self._next_attempt = time.monotonic() + RETRY_COOLDOWN
                _LOGGER.warning(
                    "Triki %s: connection failed (%r); retrying in %ss. "
                    "Is it still connected to the Zappka app / another device?",
                    self.address,
                    err,
                    RETRY_COOLDOWN,
                )
                return

            self._client = client
            _LOGGER.info("Triki %s: connected", self.address)

            try:
                battery = await client.read_gatt_char(BATTERY_LEVEL_UUID)
                self.data.battery = int(battery[0])
            except (BleakError, IndexError) as err:
                _LOGGER.debug("Triki %s: battery read failed: %s", self.address, err)

            try:
                fw_raw = await client.read_gatt_char(FIRMWARE_REV_UUID)
                self.data.firmware = (
                    fw_raw.decode("utf-8", errors="ignore").strip("\x00").strip()
                )
            except BleakError as err:
                _LOGGER.debug("Triki %s: firmware read failed: %s", self.address, err)

            try:
                await client.start_notify(UART_TX_UUID, self._on_notify)
                await self._async_send_start_stream(client)
            except BleakError as err:
                _LOGGER.warning(
                    "Triki %s: could not start motion stream: %s", self.address, err
                )

            self.data.available = True
            self.async_set_updated_data(self.data)

    async def _async_send_start_stream(self, client: BleakClient) -> None:
        rate_bytes = self.sample_rate.to_bytes(2, byteorder="little")
        start_cmd = CMD_PREFIX + rate_bytes + CMD_SUFFIX
        await client.write_gatt_char(UART_RX_UUID, start_cmd, response=False)

    def _on_disconnect(self, _client: BleakClient) -> None:
        _LOGGER.info("Triki %s: disconnected", self.address)
        self.data.available = False
        self._client = None
        self.hass.loop.call_soon_threadsafe(self.async_set_updated_data, self.data)

    async def _async_disconnect(self) -> None:
        client, self._client = self._client, None
        if client is None:
            return
        try:
            if client.is_connected:
                try:
                    await client.write_gatt_char(LED_CTRL_UUID, b"\x00", response=True)
                except BleakError:
                    pass
                try:
                    await client.write_gatt_char(UART_RX_UUID, CMD_SLEEP, response=False)
                except BleakError:
                    pass
                await client.disconnect()
        except BleakError as err:
            _LOGGER.debug("Triki %s: error during disconnect: %s", self.address, err)

    # ------------------------------------------------------------------
    # Notification parsing
    # ------------------------------------------------------------------

    @callback
    def _on_notify(self, _sender, payload: bytearray) -> None:
        if len(payload) < NOTIFY_LEN or payload[0] != NOTIFY_HEADER:
            return  # not a motion packet (e.g. a 5-byte 0x21 status/ack packet)

        (
            self.data.accel_x,
            self.data.accel_y,
            self.data.accel_z,
            self.data.gyro_x,
            self.data.gyro_y,
            self.data.gyro_z,
        ) = struct.unpack_from("<hhhhhh", payload, 2)

        button_pressed = payload[15] == 1
        button_changed = button_pressed != self.data.button_pressed
        self.data.button_pressed = button_pressed
        self.data.available = True

        now = time.monotonic()
        if button_changed or (now - self._last_push) >= MIN_PUSH_INTERVAL:
            self._last_push = now
            self.async_set_updated_data(self.data)

    # ------------------------------------------------------------------
    # Commands
    # ------------------------------------------------------------------

    async def async_set_led(self, on: bool) -> None:
        """Turn the controller's green LED on or off."""
        if self._client is None or not self._client.is_connected:
            raise HomeAssistantError("Triki controller is not connected right now")
        await self._client.write_gatt_char(
            LED_CTRL_UUID, b"\x01" if on else b"\x00", response=True
        )
        self.data.led_on = on
        self.async_set_updated_data(self.data)
