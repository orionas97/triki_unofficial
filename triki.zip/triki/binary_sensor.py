"""Binary sensor platform for Triki."""
from __future__ import annotations

from homeassistant.components.binary_sensor import (
    BinarySensorDeviceClass,
    BinarySensorEntity,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import EntityCategory
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN
from .coordinator import TrikiCoordinator
from .entity import TrikiEntity


async def async_setup_entry(
    hass: HomeAssistant, entry: ConfigEntry, async_add_entities: AddEntitiesCallback
) -> None:
    """Set up Triki binary sensors from a config entry."""
    coordinator: TrikiCoordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(
        [
            TrikiButtonSensor(coordinator),
            TrikiConnectivitySensor(coordinator),
        ]
    )


class TrikiButtonSensor(TrikiEntity, BinarySensorEntity):
    """Whether the cap's physical button is currently pressed."""

    _attr_translation_key = "button"

    def __init__(self, coordinator: TrikiCoordinator) -> None:
        super().__init__(coordinator)
        self._attr_unique_id = f"{coordinator.address}_button"

    @property
    def is_on(self) -> bool:
        return self.coordinator.data.button_pressed


class TrikiConnectivitySensor(TrikiEntity, BinarySensorEntity):
    """Whether Home Assistant currently has an active BLE connection."""

    _attr_translation_key = "connectivity"
    _attr_device_class = BinarySensorDeviceClass.CONNECTIVITY
    _attr_entity_category = EntityCategory.DIAGNOSTIC

    def __init__(self, coordinator: TrikiCoordinator) -> None:
        super().__init__(coordinator)
        self._attr_unique_id = f"{coordinator.address}_connectivity"

    @property
    def available(self) -> bool:
        # This entity reports connectivity itself, so it stays available
        # even while the device is disconnected.
        return True

    @property
    def is_on(self) -> bool:
        return self.coordinator.data.available
